JACKSON PHILAYA PHOTOGRAPHY WEBSITE

Files:
- index.html: the complete website (HTML, CSS and a tiny bit of JavaScript).

How to publish for free with GitHub Pages:
1. Sign in or create an account at https://github.com
2. Create a new public repository named exactly: yourusername.github.io
   Replace yourusername with your GitHub username.
3. Upload index.html to the repository's top level (Add file > Upload files > Commit changes).
4. Open the repository Settings > Pages and follow the Pages publishing prompt if needed.
5. Visit https://yourusername.github.io

Before sharing the website:
- Replace the sample/stock gallery photos with your own photos. In index.html, search for images.unsplash.com and replace each image URL with a publicly accessible image URL you own or have permission to use.
- The hero and About backgrounds are also stock placeholders.
- Confirm the contact email and update your social links if desired.
- GitHub Pages is free for public repositories; a custom domain is optional and usually costs extra.
